import { pgTable, text, serial, integer, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const spreadsheetConfigs = pgTable("spreadsheet_configs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  spreadsheetId: text("spreadsheet_id").notNull(),
  sheetName: text("sheet_name").notNull().default("Sheet1"),
  isActive: boolean("is_active").notNull().default(true),
});

export const spreadsheetData = pgTable("spreadsheet_data", {
  id: serial("id").primaryKey(),
  configId: integer("config_id").notNull(),
  cellAddress: text("cell_address").notNull(),
  value: real("value").notNull(),
  lastUpdated: text("last_updated").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSpreadsheetConfigSchema = createInsertSchema(spreadsheetConfigs).omit({
  id: true,
  userId: true,
  isActive: true,
});

export const insertSpreadsheetDataSchema = createInsertSchema(spreadsheetData).omit({
  id: true,
  lastUpdated: true,
});

export const updateSpreadsheetDataSchema = z.object({
  cellRange: z.string().min(1, "Cell range is required"),
  numbers: z.array(z.number()).min(1, "At least one number is required"),
});

export const readSpreadsheetDataSchema = z.object({
  range: z.string().min(1, "Range is required"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSpreadsheetConfig = z.infer<typeof insertSpreadsheetConfigSchema>;
export type SpreadsheetConfig = typeof spreadsheetConfigs.$inferSelect;
export type InsertSpreadsheetData = z.infer<typeof insertSpreadsheetDataSchema>;
export type SpreadsheetData = typeof spreadsheetData.$inferSelect;
export type UpdateSpreadsheetData = z.infer<typeof updateSpreadsheetDataSchema>;
export type ReadSpreadsheetData = z.infer<typeof readSpreadsheetDataSchema>;
