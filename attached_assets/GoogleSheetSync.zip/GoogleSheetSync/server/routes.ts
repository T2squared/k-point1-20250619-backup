import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { google } from "googleapis";
import {
  insertSpreadsheetConfigSchema,
  updateSpreadsheetDataSchema,
  readSpreadsheetDataSchema,
} from "@shared/schema";

const GOOGLE_CLIENT_EMAIL = process.env.GOOGLE_CLIENT_EMAIL || "";
const GOOGLE_PRIVATE_KEY = process.env.GOOGLE_PRIVATE_KEY || "";
const SPREADSHEET_ID = process.env.GOOGLE_SPREADSHEET_ID || "";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create JWT auth for service account
  const auth = new google.auth.JWT(
    GOOGLE_CLIENT_EMAIL,
    undefined,
    GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    ['https://www.googleapis.com/auth/spreadsheets']
  );
  
  const sheets = google.sheets({ version: 'v4', auth });

  // Get current user (demo user for this implementation)
  app.get("/api/user", async (req, res) => {
    try {
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Get spreadsheet configuration
  app.get("/api/config", async (req, res) => {
    try {
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const config = await storage.getSpreadsheetConfig(user.id);
      if (!config) {
        return res.json({ 
          spreadsheetId: SPREADSHEET_ID, 
          sheetName: "Sheet1" 
        });
      }

      res.json(config);
    } catch (error) {
      console.error("Error fetching config:", error);
      res.status(500).json({ error: "Failed to fetch configuration" });
    }
  });

  // Save spreadsheet configuration
  app.post("/api/config", async (req, res) => {
    try {
      const parsed = insertSpreadsheetConfigSchema.parse(req.body);
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const config = await storage.createSpreadsheetConfig({
        ...parsed,
        userId: user.id
      });

      res.json(config);
    } catch (error) {
      console.error("Error saving config:", error);
      res.status(500).json({ error: "Failed to save configuration" });
    }
  });

  // Read data from Google Sheets
  app.post("/api/sheets/read", async (req, res) => {
    try {
      const { range } = readSpreadsheetDataSchema.parse(req.body);
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      let config = await storage.getSpreadsheetConfig(user.id);
      if (!config) {
        // Create default config if none exists
        config = await storage.createSpreadsheetConfig({
          spreadsheetId: SPREADSHEET_ID,
          sheetName: "Sheet1",
          userId: user.id
        });
      }

      const spreadsheetId = config.spreadsheetId || SPREADSHEET_ID;
      
      // First, get the actual sheet info to verify the sheet name exists
      const spreadsheetInfo = await sheets.spreadsheets.get({
        spreadsheetId,
      });
      
      const availableSheets = spreadsheetInfo.data.sheets?.map(sheet => sheet.properties?.title).filter(Boolean) || [];
      let actualSheetName = config.sheetName;
      
      // If the configured sheet name doesn't exist, use the first available sheet
      if (!availableSheets.includes(actualSheetName)) {
        actualSheetName = availableSheets[0] || "Sheet1";
        // Update config with the correct sheet name
        await storage.createSpreadsheetConfig({
          spreadsheetId: config.spreadsheetId,
          sheetName: actualSheetName,
          userId: user.id
        });
      }

      const fullRange = `'${actualSheetName}'!${range}`;

      const response = await sheets.spreadsheets.values.get({
        spreadsheetId,
        range: fullRange,
      });

      const values = response.data.values || [];
      const data = values.map((row, rowIndex) => {
        return row.map((value, colIndex) => {
          const cellAddress = `${String.fromCharCode(65 + colIndex)}${rowIndex + 1}`;
          const numValue = parseFloat(value);
          return {
            cellAddress,
            value: isNaN(numValue) ? 0 : numValue,
            displayValue: value
          };
        });
      }).flat();

      // Update local storage
      await storage.updateSpreadsheetData(config.id, data.map(item => ({
        id: 0,
        configId: config.id,
        cellAddress: item.cellAddress,
        value: item.value,
        lastUpdated: new Date().toISOString()
      })));

      // Calculate stats
      const numbers = data.map(item => item.value).filter(val => !isNaN(val));
      const stats = {
        count: numbers.length,
        sum: numbers.reduce((acc, val) => acc + val, 0),
        average: numbers.length > 0 ? numbers.reduce((acc, val) => acc + val, 0) / numbers.length : 0
      };

      res.json({ data, stats });
    } catch (error) {
      console.error("Error reading from Google Sheets:", error);
      res.status(500).json({ error: "Failed to read from Google Sheets" });
    }
  });

  // Write data to Google Sheets
  app.post("/api/sheets/write", async (req, res) => {
    try {
      const { cellRange, numbers } = updateSpreadsheetDataSchema.parse(req.body);
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      let config = await storage.getSpreadsheetConfig(user.id);
      if (!config) {
        config = await storage.createSpreadsheetConfig({
          spreadsheetId: SPREADSHEET_ID,
          sheetName: "Sheet1",
          userId: user.id
        });
      }

      const spreadsheetId = config.spreadsheetId || SPREADSHEET_ID;
      
      // First, get the actual sheet info to verify the sheet name exists
      const spreadsheetInfo = await sheets.spreadsheets.get({
        spreadsheetId,
      });
      
      const availableSheets = spreadsheetInfo.data.sheets?.map(sheet => sheet.properties?.title).filter(Boolean) || [];
      let actualSheetName = config.sheetName;
      
      // If the configured sheet name doesn't exist, use the first available sheet
      if (!availableSheets.includes(actualSheetName)) {
        actualSheetName = availableSheets[0] || "Sheet1";
      }

      const fullRange = `'${actualSheetName}'!${cellRange}`;

      // Prepare values for Google Sheets (column-wise)
      const values = numbers.map(num => [num]);

      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: fullRange,
        valueInputOption: 'RAW',
        requestBody: {
          values
        }
      });

      res.json({ success: true, message: "Data successfully written to spreadsheet" });
    } catch (error) {
      console.error("Error writing to Google Sheets:", error);
      res.status(500).json({ error: "Failed to write to Google Sheets" });
    }
  });

  // Test Google Sheets connection
  app.get("/api/sheets/test", async (req, res) => {
    try {
      const user = await storage.getUserByUsername("demo");
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      let config = await storage.getSpreadsheetConfig(user.id);
      if (!config) {
        config = await storage.createSpreadsheetConfig({
          spreadsheetId: SPREADSHEET_ID,
          sheetName: "Sheet1",
          userId: user.id
        });
      }

      const spreadsheetId = config.spreadsheetId || SPREADSHEET_ID;

      const response = await sheets.spreadsheets.get({
        spreadsheetId,
      });

      // Get available sheet names
      const sheetNames = response.data.sheets?.map(sheet => sheet.properties?.title).filter(Boolean) || [];

      res.json({ 
        connected: true, 
        spreadsheetTitle: response.data.properties?.title || "Unknown",
        spreadsheetId,
        availableSheets: sheetNames
      });
    } catch (error) {
      console.error("Error testing Google Sheets connection:", error);
      res.status(500).json({ error: "Failed to connect to Google Sheets" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
