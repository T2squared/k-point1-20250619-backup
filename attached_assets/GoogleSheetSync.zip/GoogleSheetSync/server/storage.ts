import { 
  users, 
  spreadsheetConfigs, 
  spreadsheetData,
  type User, 
  type InsertUser,
  type SpreadsheetConfig,
  type InsertSpreadsheetConfig,
  type SpreadsheetData,
  type InsertSpreadsheetData
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getSpreadsheetConfig(userId: number): Promise<SpreadsheetConfig | undefined>;
  createSpreadsheetConfig(config: InsertSpreadsheetConfig & { userId: number }): Promise<SpreadsheetConfig>;
  updateSpreadsheetConfig(userId: number, config: Partial<InsertSpreadsheetConfig>): Promise<SpreadsheetConfig | undefined>;
  
  getSpreadsheetData(configId: number): Promise<SpreadsheetData[]>;
  createSpreadsheetData(data: InsertSpreadsheetData): Promise<SpreadsheetData>;
  updateSpreadsheetData(configId: number, data: SpreadsheetData[]): Promise<void>;
  clearSpreadsheetData(configId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private configs: Map<number, SpreadsheetConfig>;
  private data: Map<number, SpreadsheetData>;
  private userIdCounter: number;
  private configIdCounter: number;
  private dataIdCounter: number;

  constructor() {
    this.users = new Map();
    this.configs = new Map();
    this.data = new Map();
    this.userIdCounter = 1;
    this.configIdCounter = 1;
    this.dataIdCounter = 1;
    
    // Create a default user for demo purposes
    this.createUser({ username: "demo", password: "demo" });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getSpreadsheetConfig(userId: number): Promise<SpreadsheetConfig | undefined> {
    return Array.from(this.configs.values()).find(
      (config) => config.userId === userId && config.isActive
    );
  }

  async createSpreadsheetConfig(config: InsertSpreadsheetConfig & { userId: number }): Promise<SpreadsheetConfig> {
    // Deactivate existing configs for this user
    for (const [id, existingConfig] of this.configs.entries()) {
      if (existingConfig.userId === config.userId) {
        this.configs.set(id, { ...existingConfig, isActive: false });
      }
    }

    const id = this.configIdCounter++;
    const newConfig: SpreadsheetConfig = { 
      ...config, 
      id,
      isActive: true 
    };
    this.configs.set(id, newConfig);
    return newConfig;
  }

  async updateSpreadsheetConfig(userId: number, config: Partial<InsertSpreadsheetConfig>): Promise<SpreadsheetConfig | undefined> {
    const existingConfig = await this.getSpreadsheetConfig(userId);
    if (!existingConfig) return undefined;

    const updatedConfig: SpreadsheetConfig = {
      ...existingConfig,
      ...config
    };
    this.configs.set(existingConfig.id, updatedConfig);
    return updatedConfig;
  }

  async getSpreadsheetData(configId: number): Promise<SpreadsheetData[]> {
    return Array.from(this.data.values()).filter(
      (item) => item.configId === configId
    );
  }

  async createSpreadsheetData(data: InsertSpreadsheetData): Promise<SpreadsheetData> {
    const id = this.dataIdCounter++;
    const newData: SpreadsheetData = {
      ...data,
      id,
      lastUpdated: new Date().toISOString()
    };
    this.data.set(id, newData);
    return newData;
  }

  async updateSpreadsheetData(configId: number, data: SpreadsheetData[]): Promise<void> {
    // Clear existing data for this config
    await this.clearSpreadsheetData(configId);
    
    // Add new data
    for (const item of data) {
      await this.createSpreadsheetData({
        configId,
        cellAddress: item.cellAddress,
        value: item.value
      });
    }
  }

  async clearSpreadsheetData(configId: number): Promise<void> {
    const toDelete = Array.from(this.data.entries())
      .filter(([_, item]) => item.configId === configId)
      .map(([id, _]) => id);
    
    toDelete.forEach(id => this.data.delete(id));
  }
}

export const storage = new MemStorage();
