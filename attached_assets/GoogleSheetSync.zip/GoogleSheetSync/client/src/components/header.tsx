import { useQuery } from "@tanstack/react-query";
import { sheetsApi } from "@/lib/sheets-api";

export default function Header() {
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    queryFn: () => sheetsApi.getCurrentUser(),
  });

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <i className="fas fa-table text-primary text-2xl mr-3"></i>
            <h1 className="text-xl font-semibold text-gray-900">Google Sheets Data Manager</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <i className="fas fa-user text-gray-600 text-sm"></i>
              </div>
              <span className="text-sm text-gray-700">
                {user?.username || "Loading..."}
              </span>
            </div>
            <button className="text-sm text-gray-500 hover:text-gray-700 transition-colors">
              <i className="fas fa-sign-out-alt mr-1"></i>
              Sign Out
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
