
import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { sheetsApi, type ConfigData } from "@/lib/sheets-api";

const configSchema = z.object({
  spreadsheetId: z.string().min(1, "Spreadsheet ID is required"),
  sheetName: z.string().min(1, "Sheet name is required"),
});

type ConfigFormData = z.infer<typeof configSchema>;

export default function ApiConfiguration() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: config, isLoading } = useQuery({
    queryKey: ["/api/config"],
    queryFn: () => sheetsApi.getConfig(),
  });

  const { data: connection } = useQuery({
    queryKey: ["/api/sheets/test"],
    queryFn: () => sheetsApi.testConnection(),
    retry: false,
  });

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ConfigFormData>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      spreadsheetId: "",
      sheetName: "Sheet1",
    },
    values: config ? {
      spreadsheetId: config.spreadsheetId || "",
      sheetName: config.sheetName || "Sheet1",
    } : undefined,
  });

  const saveConfigMutation = useMutation({
    mutationFn: (data: ConfigFormData) => sheetsApi.saveConfig(data),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Configuration saved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/config"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sheets/test"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save configuration",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ConfigFormData) => {
    saveConfigMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <span className="text-sm text-gray-600 mt-2 block">Loading configuration...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 flex items-center">
          <i className="fas fa-cog text-primary mr-2"></i>
          API Configuration
        </h3>
        <p className="text-sm text-gray-600 mt-1">Configure your Google Sheets API connection</p>
      </div>

      <div className="p-6">
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="spreadsheetId" className="block text-sm font-medium text-gray-700 mb-2">
                Spreadsheet ID
              </Label>
              <Input
                {...register("spreadsheetId")}
                id="spreadsheetId"
                placeholder="1abc123def456ghi789jkl"
                className="font-mono"
              />
              {errors.spreadsheetId && (
                <p className="mt-1 text-xs text-destructive">{errors.spreadsheetId.message}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">Found in the Google Sheets URL</p>
            </div>

            <div>
              <Label htmlFor="sheetName" className="block text-sm font-medium text-gray-700 mb-2">
                Sheet Name
              </Label>
              <Input
                {...register("sheetName")}
                id="sheetName"
                placeholder="Sheet1"
              />
              {errors.sheetName && (
                <p className="mt-1 text-xs text-destructive">{errors.sheetName.message}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">Name of the sheet tab (case-sensitive)</p>
            </div>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${connection?.connected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm text-gray-600">
                {connection?.connected ? 'Connected' : 'Not connected'}
              </span>
              {connection?.spreadsheetTitle && (
                <span className="text-sm text-gray-500">
                  - {connection.spreadsheetTitle}
                </span>
              )}
            </div>
            <Button 
              type="submit" 
              className="bg-primary text-white hover:bg-blue-700"
              disabled={saveConfigMutation.isPending}
            >
              {saveConfigMutation.isPending ? "Saving..." : "Save Configuration"}
            </Button>
          </div>
        </form>

        {saveConfigMutation.isPending && (
          <div className="mt-4 p-4 bg-blue-50 rounded-md">
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-3"></div>
              <span className="text-sm text-blue-700">Saving configuration...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
