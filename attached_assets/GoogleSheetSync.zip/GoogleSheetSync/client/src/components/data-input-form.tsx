import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { sheetsApi } from "@/lib/sheets-api";

const formSchema = z.object({
  cellRange: z.string().min(1, "Cell range is required"),
  numbers: z.string().min(1, "Numbers are required"),
});

type FormData = z.infer<typeof formSchema>;

export default function DataInputForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      cellRange: "A1:A10",
      numbers: "",
    },
  });

  const writeDataMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const numbers = data.numbers
        .split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0)
        .map(line => {
          const num = parseFloat(line);
          if (isNaN(num)) {
            throw new Error(`Invalid number: ${line}`);
          }
          return num;
        });

      if (numbers.length === 0) {
        throw new Error("No valid numbers found");
      }

      return sheetsApi.writeData({
        cellRange: data.cellRange,
        numbers,
      });
    },
    onSuccess: (result) => {
      toast({
        title: "Success",
        description: result.message,
      });
      reset();
      // Invalidate any cached data
      queryClient.invalidateQueries({ queryKey: ["/api/sheets/read"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add numbers to spreadsheet",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    writeDataMutation.mutate(data);
  };

  const handleClear = () => {
    reset();
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <h3 className="text-lg font-medium text-gray-900 flex items-center">
          <i className="fas fa-plus-circle text-primary mr-2"></i>
          Add Numbers to Spreadsheet
        </h3>
        <p className="text-sm text-gray-600 mt-1">Enter numbers to add to your Google Spreadsheet</p>
      </div>
      
      <div className="p-6">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <Label htmlFor="cellRange" className="block text-sm font-medium text-gray-700 mb-2">
              Cell Range
            </Label>
            <Input
              {...register("cellRange")}
              id="cellRange"
              placeholder="A1:A10"
              className="font-mono"
            />
            {errors.cellRange && (
              <p className="mt-1 text-xs text-destructive">{errors.cellRange.message}</p>
            )}
            <p className="mt-1 text-xs text-gray-500">Specify the range where numbers will be added (e.g., A1:A10)</p>
          </div>

          <div>
            <Label htmlFor="numbers" className="block text-sm font-medium text-gray-700 mb-2">
              Numbers
            </Label>
            <Textarea
              {...register("numbers")}
              id="numbers"
              rows={6}
              placeholder="Enter numbers (one per line)&#10;123&#10;456&#10;789"
              className="font-mono resize-none"
            />
            {errors.numbers && (
              <p className="mt-1 text-xs text-destructive">{errors.numbers.message}</p>
            )}
            <p className="mt-1 text-xs text-gray-500">Enter one number per line</p>
          </div>

          <div className="flex items-center space-x-3">
            <Button 
              type="submit"
              disabled={writeDataMutation.isPending}
              className="flex-1 bg-primary text-white hover:bg-blue-700"
            >
              <i className="fas fa-upload mr-2"></i>
              {writeDataMutation.isPending ? "Adding..." : "Add to Spreadsheet"}
            </Button>
            <Button 
              type="button"
              variant="outline"
              onClick={handleClear}
              disabled={writeDataMutation.isPending}
            >
              Clear
            </Button>
          </div>
        </form>

        {writeDataMutation.isPending && (
          <div className="mt-4 p-4 bg-blue-50 rounded-md">
            <div className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-3"></div>
              <span className="text-sm text-blue-700">Adding numbers to spreadsheet...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
