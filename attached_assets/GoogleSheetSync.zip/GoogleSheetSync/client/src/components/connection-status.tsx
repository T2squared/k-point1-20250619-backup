import { useQuery, useQueryClient } from "@tanstack/react-query";
import { sheetsApi } from "@/lib/sheets-api";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function ConnectionStatus() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: connection, isLoading } = useQuery({
    queryKey: ["/api/sheets/test"],
    queryFn: () => sheetsApi.testConnection(),
    retry: false,
  });

  const handleReconnect = async () => {
    try {
      await queryClient.invalidateQueries({ queryKey: ["/api/sheets/test"] });
      toast({
        title: "Connection refreshed",
        description: "Successfully refreshed Google Sheets connection",
      });
    } catch (error) {
      toast({
        title: "Connection failed",
        description: "Failed to refresh Google Sheets connection",
        variant: "destructive",
      });
    }
  };

  const connectionStatus = isLoading ? "connecting" : connection?.connected ? "connected" : "disconnected";
  const statusColor = connectionStatus === "connected" ? "bg-secondary" : 
                     connectionStatus === "connecting" ? "bg-warning" : "bg-destructive";

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="flex items-center">
            <div className={`w-3 h-3 ${statusColor} rounded-full mr-3`}></div>
            <div>
              <h2 className="text-lg font-medium text-gray-900">Spreadsheet Connection</h2>
              <p className="text-sm text-gray-600">
                {connection?.spreadsheetTitle || "Loading..."}
              </p>
            </div>
          </div>
        </div>
        <Button 
          onClick={handleReconnect}
          variant="outline"
          className="text-primary border-primary hover:bg-blue-50"
        >
          <i className="fas fa-sync-alt mr-2"></i>
          Refresh Connection
        </Button>
      </div>
      <div className="mt-4 flex items-center text-sm text-gray-500">
        <i className="fas fa-link mr-2"></i>
        <span className="font-mono text-xs">
          {connection?.spreadsheetId ? 
            `https://docs.google.com/spreadsheets/d/${connection.spreadsheetId}` : 
            "No spreadsheet configured"
          }
        </span>
      </div>
    </div>
  );
}
