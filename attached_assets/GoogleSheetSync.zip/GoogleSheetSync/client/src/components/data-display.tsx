import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { sheetsApi, type ReadDataResponse } from "@/lib/sheets-api";

const rangeSchema = z.object({
  range: z.string().min(1, "Range is required"),
});

type RangeFormData = z.infer<typeof rangeSchema>;

export default function DataDisplay() {
  const { toast } = useToast();
  const [currentRange, setCurrentRange] = useState("A1:A20");
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<RangeFormData>({
    resolver: zodResolver(rangeSchema),
    defaultValues: {
      range: currentRange,
    },
  });

  const readDataMutation = useMutation({
    mutationFn: (range: string) => sheetsApi.readData(range),
    onSuccess: (data) => {
      setCurrentRange(data ? "loaded" : "error");
      toast({
        title: "Success",
        description: "Data loaded successfully from spreadsheet",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to load data from spreadsheet",
        variant: "destructive",
      });
    },
  });

  const { data: spreadsheetData, isLoading } = useQuery({
    queryKey: ["/api/sheets/read", currentRange],
    queryFn: () => sheetsApi.readData(currentRange),
    enabled: currentRange !== "" && currentRange !== "error",
    retry: false,
  });

  const onSubmit = (data: RangeFormData) => {
    setCurrentRange(data.range);
    readDataMutation.mutate(data.range);
  };

  const handleRefresh = () => {
    readDataMutation.mutate(currentRange);
  };

  const data = spreadsheetData?.data || [];
  const stats = spreadsheetData?.stats || { count: 0, sum: 0, average: 0 };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900 flex items-center">
            <i className="fas fa-table text-primary mr-2"></i>
            Retrieved Data
          </h3>
          <Button
            onClick={handleRefresh}
            variant="outline"
            size="sm"
            className="text-primary border-primary hover:bg-blue-50"
          >
            <i className="fas fa-sync-alt mr-1"></i>
            Refresh
          </Button>
        </div>
        <p className="text-sm text-gray-600 mt-1">Numbers currently in your Google Spreadsheet</p>
      </div>
      
      <div className="p-6">
        <div className="mb-4">
          <Label htmlFor="displayRange" className="block text-sm font-medium text-gray-700 mb-2">
            Display Range
          </Label>
          <form onSubmit={handleSubmit(onSubmit)} className="flex space-x-2">
            <Input
              {...register("range")}
              id="displayRange"
              placeholder="A1:A20"
              className="flex-1 font-mono"
            />
            <Button type="submit" className="bg-primary text-white hover:bg-blue-700">
              Load
            </Button>
          </form>
          {errors.range && (
            <p className="mt-1 text-xs text-destructive">{errors.range.message}</p>
          )}
        </div>

        <div className="border border-gray-200 rounded-md overflow-hidden">
          <div className="bg-gray-50 px-4 py-2 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-700">Cell</span>
              <span className="text-sm font-medium text-gray-700">Value</span>
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {isLoading || readDataMutation.isPending ? (
              <div className="p-4 text-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary mx-auto"></div>
                <span className="text-sm text-gray-600 mt-2 block">Loading data...</span>
              </div>
            ) : data.length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                <i className="fas fa-table text-2xl mb-2 block"></i>
                <span className="text-sm">No data available. Load a range to display data.</span>
              </div>
            ) : (
              data.map((item, index) => (
                <div 
                  key={`${item.cellAddress}-${index}`}
                  className="px-4 py-3 border-b border-gray-100 hover:bg-gray-50 transition-colors last:border-b-0"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-mono text-gray-600">{item.cellAddress}</span>
                    <span className="text-sm font-mono text-gray-900">
                      {item.displayValue || item.value}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-lg font-semibold text-gray-900">{stats.count}</div>
            <div className="text-xs text-gray-500">Total Cells</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-gray-900">{stats.sum.toFixed(2)}</div>
            <div className="text-xs text-gray-500">Sum</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-semibold text-gray-900">{stats.average.toFixed(2)}</div>
            <div className="text-xs text-gray-500">Average</div>
          </div>
        </div>
      </div>
    </div>
  );
}
