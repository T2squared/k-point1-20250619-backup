import Header from "@/components/header";
import ConnectionStatus from "@/components/connection-status";
import DataInputForm from "@/components/data-input-form";
import DataDisplay from "@/components/data-display";
import ApiConfiguration from "@/components/api-configuration";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ConnectionStatus />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <DataInputForm />
          <DataDisplay />
        </div>
        
        <ApiConfiguration />
      </main>
    </div>
  );
}
