import { apiRequest } from "./queryClient";

export interface SpreadsheetData {
  cellAddress: string;
  value: number;
  displayValue?: string;
}

export interface SpreadsheetStats {
  count: number;
  sum: number;
  average: number;
}

export interface ReadDataResponse {
  data: SpreadsheetData[];
  stats: SpreadsheetStats;
}

export interface WriteDataRequest {
  cellRange: string;
  numbers: number[];
}

export interface ConfigData {
  spreadsheetId: string;
  sheetName: string;
}

export interface ConnectionTestResponse {
  connected: boolean;
  spreadsheetTitle?: string;
  spreadsheetId?: string;
  availableSheets?: string[];
}

export const sheetsApi = {
  async readData(range: string): Promise<ReadDataResponse> {
    const response = await apiRequest("POST", "/api/sheets/read", { range });
    return response.json();
  },

  async writeData(data: WriteDataRequest): Promise<{ success: boolean; message: string }> {
    const response = await apiRequest("POST", "/api/sheets/write", data);
    return response.json();
  },

  async getConfig(): Promise<ConfigData> {
    const response = await apiRequest("GET", "/api/config");
    return response.json();
  },

  async saveConfig(config: ConfigData): Promise<ConfigData> {
    const response = await apiRequest("POST", "/api/config", config);
    return response.json();
  },

  async testConnection(): Promise<ConnectionTestResponse> {
    const response = await apiRequest("GET", "/api/sheets/test");
    return response.json();
  },

  async getCurrentUser(): Promise<{ id: number; username: string }> {
    const response = await apiRequest("GET", "/api/user");
    return response.json();
  },
};
